

```python
import pandas as pd
```


```python
movies=pd.read_csv('https://raw.githubusercontent.com/justmarkham/pandas-videos/master/data/imdb_1000.csv')
```


```python
movies.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>star_rating</th>
      <th>title</th>
      <th>content_rating</th>
      <th>genre</th>
      <th>duration</th>
      <th>actors_list</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9.3</td>
      <td>The Shawshank Redemption</td>
      <td>R</td>
      <td>Crime</td>
      <td>142</td>
      <td>[u'Tim Robbins', u'Morgan Freeman', u'Bob Gunt...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>9.2</td>
      <td>The Godfather</td>
      <td>R</td>
      <td>Crime</td>
      <td>175</td>
      <td>[u'Marlon Brando', u'Al Pacino', u'James Caan']</td>
    </tr>
    <tr>
      <th>2</th>
      <td>9.1</td>
      <td>The Godfather: Part II</td>
      <td>R</td>
      <td>Crime</td>
      <td>200</td>
      <td>[u'Al Pacino', u'Robert De Niro', u'Robert Duv...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>9.0</td>
      <td>The Dark Knight</td>
      <td>PG-13</td>
      <td>Action</td>
      <td>152</td>
      <td>[u'Christian Bale', u'Heath Ledger', u'Aaron E...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>8.9</td>
      <td>Pulp Fiction</td>
      <td>R</td>
      <td>Crime</td>
      <td>154</td>
      <td>[u'John Travolta', u'Uma Thurman', u'Samuel L....</td>
    </tr>
  </tbody>
</table>
</div>




```python
movies.dtypes
```




    star_rating       float64
    title              object
    content_rating     object
    genre              object
    duration            int64
    actors_list        object
    dtype: object




```python
movies.genre.describe()
```




    count       979
    unique       16
    top       Drama
    freq        278
    Name: genre, dtype: object




```python
movies.genre.value_counts(normalize=True)
```




    Drama        0.283963
    Comedy       0.159346
    Action       0.138917
    Crime        0.126660
    Biography    0.078652
    Adventure    0.076609
    Animation    0.063330
    Horror       0.029622
    Mystery      0.016343
    Western      0.009193
    Thriller     0.005107
    Sci-Fi       0.005107
    Film-Noir    0.003064
    Family       0.002043
    Fantasy      0.001021
    History      0.001021
    Name: genre, dtype: float64




```python
movies.genre.value_counts().head()
```




    Drama        278
    Comedy       156
    Action       136
    Crime        124
    Biography     77
    Name: genre, dtype: int64




```python
movies.genre.unique()
```




    array(['Crime', 'Action', 'Drama', 'Western', 'Adventure', 'Biography',
           'Comedy', 'Animation', 'Mystery', 'Horror', 'Film-Noir', 'Sci-Fi',
           'History', 'Thriller', 'Family', 'Fantasy'], dtype=object)




```python
movies.genre.nunique()
```




    16




```python
pd.crosstab(movies.genre,movies.content_rating)
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>content_rating</th>
      <th>APPROVED</th>
      <th>G</th>
      <th>GP</th>
      <th>NC-17</th>
      <th>NOT RATED</th>
      <th>PASSED</th>
      <th>PG</th>
      <th>PG-13</th>
      <th>R</th>
      <th>TV-MA</th>
      <th>UNRATED</th>
      <th>X</th>
    </tr>
    <tr>
      <th>genre</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Action</th>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>11</td>
      <td>44</td>
      <td>67</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Adventure</th>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
      <td>1</td>
      <td>21</td>
      <td>23</td>
      <td>17</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Animation</th>
      <td>3</td>
      <td>20</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>25</td>
      <td>5</td>
      <td>5</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Biography</th>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>6</td>
      <td>29</td>
      <td>36</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Comedy</th>
      <td>9</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>16</td>
      <td>3</td>
      <td>23</td>
      <td>23</td>
      <td>73</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
    </tr>
    <tr>
      <th>Crime</th>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>7</td>
      <td>1</td>
      <td>6</td>
      <td>4</td>
      <td>87</td>
      <td>0</td>
      <td>11</td>
      <td>1</td>
    </tr>
    <tr>
      <th>Drama</th>
      <td>12</td>
      <td>3</td>
      <td>0</td>
      <td>4</td>
      <td>24</td>
      <td>1</td>
      <td>25</td>
      <td>55</td>
      <td>143</td>
      <td>1</td>
      <td>9</td>
      <td>1</td>
    </tr>
    <tr>
      <th>Family</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Fantasy</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Film-Noir</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>History</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Horror</th>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>16</td>
      <td>0</td>
      <td>5</td>
      <td>1</td>
    </tr>
    <tr>
      <th>Mystery</th>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>6</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Sci-Fi</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Thriller</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Western</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
movies.duration.value_counts()
```




    112    23
    113    22
    102    20
    101    20
    129    19
    120    18
    105    18
    126    18
    98     18
    130    18
    100    17
    121    17
    116    17
    124    16
    122    16
    118    16
    115    16
    96     16
    104    16
    110    16
    107    16
    109    16
    119    15
    114    15
    99     15
    108    15
    94     14
    117    14
    106    14
    93     14
           ..
    70      1
    69      1
    67      1
    66      1
    242     1
    238     1
    195     1
    229     1
    224     1
    220     1
    216     1
    212     1
    207     1
    205     1
    202     1
    201     1
    200     1
    194     1
    159     1
    193     1
    187     1
    186     1
    184     1
    183     1
    182     1
    180     1
    177     1
    168     1
    166     1
    64      1
    Name: duration, dtype: int64




```python
%matplotlib inline
```


```python
movies.duration.plot(kind='bar')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x18d297bfa58>




![png](output_12_1.png)



```python
movies.duration.plot(kind='hist')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x18d29c51dd8>




![png](output_13_1.png)



```python
movies.genre.value_counts().plot(kind='bar')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x18d2b5b45f8>




![png](output_14_1.png)



```python

```
